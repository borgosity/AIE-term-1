#include <iostream>
#include <vector>

#include "StringOO.h"
#include "GameFunctions.h"
#include "Question.h"

void ChallengeTest()
{
	// human player variables
	int humanLoc = 0;
	const char * name = "Barry";
	int strength = 10;
	int health = 100;
	int luck = 10;
	int intellegence = 10;

	// initialise human
	Human Human(humanLoc, name, strength, health, luck, intellegence);
	Human.SetLocation(0);
	
	StringOO Question1 = ">> What day is Wednesday? \n  a) the third day \n  b) hump day \n  c) the day after Tuesday";
	StringOO Answer1 = "the day after Tuesday";
	Question Q1(Question1, Answer1);
	Q1.SetDifficulty(2);

	//const int userInputLimit = 11;
	//char userInput[userInputLimit] = {};

	//std::cin.getline(userInput, userInputLimit);

	ApplyChallenge(Q1, Human);
}


int main()
{
	ChallengeTest();
	GameEngine();
	return 0;
}

