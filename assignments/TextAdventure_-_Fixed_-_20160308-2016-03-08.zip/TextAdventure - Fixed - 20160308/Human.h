#pragma once
#include "Player.h"
class Human :
	public Player
{
public:
	Human();
	Human(int location, const char * name, int strength, int health, int luck, int intellegence);
	virtual ~Human();
	int GetChallenge();
	int GetHeading();
	int GetPrevHeading();
	int GetIntellegence();
	void SetChallenge(int challenge);
	void SetHeading(int heading);
	void SetPrevHeading(int prevHeading);
protected:
	int m_intellegence;
	int m_challenge;
	int m_heading;
	int m_prevHeading;
private:
	void init();
};

