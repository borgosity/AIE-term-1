#pragma once
#include "Player.h"
class Enemy :
	public Player
{
public:
	Enemy();
	virtual ~Enemy();
};

