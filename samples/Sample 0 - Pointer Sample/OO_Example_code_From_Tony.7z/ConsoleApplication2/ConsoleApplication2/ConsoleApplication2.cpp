#include "objects.h"
// ConsoleApplication2.cpp : Defines the entry point for the console application.
//

#include "objects.h"
#include <iostream>
using namespace std;

#include "stdafx.h"

void inheritanceExample()
{
	EnemyType1* enemy1 = new EnemyType1(40, 10);
	EnemyType2* enemy2 = new EnemyType2(10, 15);
	EnemyType3* enemy3 = new EnemyType3(10, 5);

	Base* gameObjects[] = { enemy1, enemy2, enemy3 };

	gameObjects[0]->myVirtualFunction();
	gameObjects[1]->myVirtualFunction();
	gameObjects[2]->myVirtualFunction();

	delete(enemy1);
	delete(enemy2);
	delete(enemy3);
}

void diamondExample()
{
	diamondExampleMultipleDerived diamondExample;
	//diamondExample.diamondFunction(); //we can't do this because of multiple inheritance
}

void polymorphismExample()
{
	EnemyType1* enemy1 = new EnemyType1(40, 10);
	EnemyType2* enemy2 = new EnemyType2(10, 15);
	EnemyType3* enemy3 = new EnemyType3(10, 5);
		
	Base* gameObjects[] = { enemy1, enemy2, enemy3};

	gameObjects[0]->myVirtualFunction();
	gameObjects[1]->myVirtualFunction();
	gameObjects[2]->myVirtualFunction();



	while (true)
	{
		float delta = 1; //should be time delta but we don't have this yet
		//remove all items from the display
		for (Base* object : gameObjects)
		{
			object->unRender();
		}
		//update our enemies positions
		for (Base* object : gameObjects)
		{
			object->update(delta);
		}

		//redraw them in the new positions
		for (Base* object : gameObjects)
		{
			object->render();
		}

		//wait for a bit
		for (int i = 0; i < 50000000; i++);
	}
}

int _tmain(int argc, _TCHAR* argv[])
{

	inheritanceExample();
//	diamondExample();  //demonstrates multiple inheritance
//	polymorphismExample(); //demonstrates polymorphism
	while (1);


	return 0;
}


