#pragma once

extern const float PI; //PI declaration
int myFunc(int); //function declaration