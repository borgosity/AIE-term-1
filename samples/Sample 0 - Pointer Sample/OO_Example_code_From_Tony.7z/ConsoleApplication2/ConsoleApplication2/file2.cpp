#include "file2.h"

const float PI = 3.14;  //definition for PI

int myFunc(int intVar)  //definition for myFunc
{
	static int localInt = 0;
	return intVar++;
}