#include "objects.h"
#include <iostream>
using namespace std;
#include <windows.h>
#include <conio.h>


Vector2::Vector2(float x, float y)
{
	_x = x;
	_y = y;
}

Vector2 Vector2::operator + (Vector2& other)
{
	return Vector2(_x + other._x,  _y+other._y); //add our two vectors component wise
}

Vector2 Vector2::operator += (Vector2& other)
{
	_x += other._x;
	_y += other._y; //add our two vectors component wise
	return *this;
}

Vector2 Vector2::operator * (float& scalar)
{
	return Vector2(_x * scalar, _y * scalar); //add our two vectors component wise
}

Base::Base(float x, float y, char graphic)
{
	_position = Vector2(x, y);
	_graphic = graphic;
	cout << "Base constructor " << endl;
}

Base::~Base()
{
	cout << "Base destructor " << endl;
}

void Base::render()
{
	HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD CursorPosition;
	CursorPosition.X = _position._x;
	CursorPosition.Y = _position._y;
	SetConsoleCursorPosition(console, CursorPosition);
	cout << _graphic;
	CursorPosition.X = 0;
	CursorPosition.Y = 0;
	SetConsoleCursorPosition(console, CursorPosition);
}

void Base::update(float delta)
{
	_position += (_velocity*delta);
}

void Base::myVirtualFunction()
{
	cout << "base function" << endl;
}

void Base::unRender()
{
	HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD CursorPosition;
	CursorPosition.X = _position._x;
	CursorPosition.Y = _position._y;
	SetConsoleCursorPosition(console, CursorPosition);
	cout << ' ';
	CursorPosition.X = 0;
	CursorPosition.Y = 0;
	SetConsoleCursorPosition(console, CursorPosition);
}

EnemyType1::EnemyType1(float x, float y) : Base(x, y, 'H')
{
	cout <<"EnemyType1 constructor " << endl;
	_velocity = Vector2(1,0);
}

EnemyType1::~EnemyType1()
{
	cout << "EnemyType1 destructor " << endl;
}

void EnemyType1::update(float delta)
{
	Base::update(delta);

	if (_position._x <= 0 && _velocity._x < 0)
	{
		_velocity._x *= -1;
	}

	if (_position._x>= 79 && _velocity._x > 0)
	{
		_velocity._x *= -1;
	}
}

EnemyType2::EnemyType2(float x, float y) : Base(x, y, 'V')
{
	_velocity = Vector2(0, 1);
	cout << "EnemyType2 constructor " << endl;
}

EnemyType2::~EnemyType2()
{
	cout << "EnemyType2 destructor " << endl;
}

void EnemyType2::update(float delta)
{
	Base::update(delta);

	if (_position._y <= 0 && _velocity._y < 0)
	{
		_velocity._y *= -1;
	}

	if (_position._y >= 25 && _velocity._y > 0)
	{
		_velocity._y *= -1;
	}
}

void EnemyType2::myVirtualFunction()
{
	cout << "EnemyType2 function" << endl;
}

EnemyType3::EnemyType3(float x, float y) : Base(x, y, 'X')
{
	_velocity = Vector2(1.5, 1);
	cout << "EnemyType3 constructor " << endl;
}

EnemyType3::~EnemyType3()
{
	cout << "EnemyType3 destructor " << endl;
}

void EnemyType3::update(float delta)
{
	Base::update(delta);

	if (_position._y <= 0 && _velocity._y < 0)
	{
		_velocity._y *= -1;
	}

	if (_position._y >= 25 && _velocity._y > 0)
	{
		_velocity._y *= -1;
	}

	if (_position._x <= 0 && _velocity._x < 0)
	{
		_velocity._x *= -1;
	}

	if (_position._x >= 79 && _velocity._x > 0)
	{
		_velocity._x *= -1;
	}
}

void EnemyType3::myVirtualFunction()
{
	cout << "EnemyType3 function"<<endl;
}

Ball::Ball(float x, float y) : Base(x, y, '0')
{
	_velocity = Vector2(1.5, 0);
	cout << "Ball constructor " << endl;
}

Ball::~Ball()
{
	cout << "Ball destructor " << endl;
}

void Ball::update(float delta)
{
	Base::update(delta);
	_velocity._y += delta * .05f;
	if (_position._y <= 0 && _velocity._y < 0)
	{
		_velocity._y  = 0;
	}

	if (_position._y >= 25 && _velocity._y > 0)
	{
		_velocity._y *= -1;
	}

	if (_position._x <= 0 && _velocity._x < 0)
	{
		_velocity._x *= -1;
	}

	if (_position._x >= 79 && _velocity._x > 0)
	{
		_velocity._x *= -1;
	}
}


void diamondExampleDerived1::diamondFunction()
{
	cout << "diamondExampleDerived1" << endl;
}

void diamondExampleDerived2::diamondFunction()
{
	cout << "diamondExampleDerived2" << endl;
}