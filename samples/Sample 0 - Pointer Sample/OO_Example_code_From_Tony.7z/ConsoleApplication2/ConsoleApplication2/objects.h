#pragma once
#define UP_ARROW    72
#define LEFT_ARROW  75
#define DOWN_ARROW  80
#define RIGHT_ARROW 77

struct Vector2
{
	float _x, _y; //components which make up our vector2
	Vector2(float x, float y); //custom constructor
	Vector2(){}; //default constructor
	Vector2 operator + (Vector2& other); //overload our plus operator
	Vector2 operator * (float &scalar); //overload our plus operator
	Vector2 operator += (Vector2& other); //overload our plus operator
};


class Base
{
protected:
	Vector2 _position;
	char _graphic;
	Vector2 _velocity;
	Base(){}; //default constructor
	Base(float x, float y, char graphic); //custom constructor
	~Base();

public:
	virtual void update(float); //default update function
	virtual void render(); //render function
	virtual void unRender(); //function to remove from display
	virtual void myVirtualFunction();
};


class EnemyType1:public Base  //our derived enemy class
{
public:
	EnemyType1(float x, float y); //our enemy constructor
	~EnemyType1();
	void update(float); //our update function
};

class EnemyType2 :public Base //our derived enemy class
{
public:
	EnemyType2(float x, float y); //our enemy constructor
	~EnemyType2();
	void update(float); //our update function
	void myVirtualFunction();
};

class EnemyType3 :public Base //our derived enemy class
{
public:
	EnemyType3(float x, float y); //our enemy constructor
	~EnemyType3();
	void update(float); //our update function
	void myVirtualFunction();
};

class Ball :public Base //our derived enemy class
{
public:
	Ball(float x, float y); //our enemy constructor
	~Ball();
	void update(float); //our update function
};





//diamond inheritance example

class diamondExampleBase
{
protected:
	virtual void diamondFunction() = 0;
};


class diamondExampleDerived1 :public diamondExampleBase
{
public:
	virtual void diamondFunction();
};

class diamondExampleDerived2 :public diamondExampleBase
{
public:
	virtual void diamondFunction();
};

class diamondExampleMultipleDerived :public diamondExampleDerived1, public diamondExampleDerived2
{
};